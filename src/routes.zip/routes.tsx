import { lazy } from 'react';
import type { ReactNode } from 'react';

// 1. 基础组件 (通常建议 Layout 不可懒加载，以保证结构稳定性，但 Login 可以懒加载)
import AppLayout from '@/components/layouts/AppLayout';

// 2. 懒加载页面组件 (Code Splitting)
// 只有当路由被访问时，才会加载对应的代码包
const LoginPage = lazy(() => import('@/pages/LoginPage'));
const ReviewPage = lazy(() => import('@/pages/ReviewPage'));
const MyReviewsPage = lazy(() => import('@/pages/MyReviewsPage'));
const MyStatsPage = lazy(() => import('@/pages/MyStatsPage'));
const StatsPage = lazy(() => import('@/pages/StatsPage'));
const UserManagePage = lazy(() => import('@/pages/UserManagePage'));
const CyclePage = lazy(() => import('@/pages/CyclePage'));
const TrendAnalysisPage = lazy(() => import('@/pages/TrendAnalysisPage'));
const GuidePage = lazy(() => import('@/pages/Guide'));

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  public?: boolean; // 是否公开访问（不登录也能看）
  children?: RouteConfig[]; // 子路由
  meta?: { roles?: string[]; title?: string }; // 扩展元数据，方便后续做角色控制或页面标题设置
}

// ========== 路由配置分组 ==========

/** 公开路由（无需登录） */
const PUBLIC_ROUTES: RouteConfig[] = [
  {
    name: '登录',
    path: '/login',
    element: <LoginPage />,
    public: true,
  },
];

/** 主应用路由 (在 AppLayout 内部) */
const LAYOUT_CHILDREN: RouteConfig[] = [
  {
    name: '填写评价',
    path: 'review',
    element: <ReviewPage />,
    meta: { roles: ['admin', 'reviewer'] },
  },
  {
    name: '我的评价',
    path: 'my-reviews',
    element: <MyReviewsPage />,
  },
  {
    name: '我的统计',
    path: 'my-stats',
    element: <MyStatsPage />,
  },
  {
    name: '评价统计',
    path: 'stats',
    element: <StatsPage />,
    meta: { roles: ['admin', 'reviewer'] },
  },
  {
    name: '趋势分析',
    path: 'trend',
    element: <TrendAnalysisPage />,
  },
  {
    name: '使用指南',
    path: 'guide',
    element: <GuidePage />,
  },
  {
    name: '用户管理',
    path: 'admin/users',
    element: <UserManagePage />,
    meta: { roles: ['admin'] },
  },
  {
    name: '评价周期',
    path: 'admin/cycles',
    element: <CyclePage />,
    meta: { roles: ['admin'] },
  },
];

/** 主布局配置 */
const MAIN_LAYOUT_ROUTE: RouteConfig = {
  name: '主布局',
  path: '/', // 注意：React Router v6 中，父路由 path="/" 会匹配所有子路由，需要包含 <Outlet />
  element: <AppLayout />,
  public: false,
  children: LAYOUT_CHILDREN,
};

// ========== 导出完整配置 ==========
export const routes: RouteConfig[] = [
  ...PUBLIC_ROUTES,
  MAIN_LAYOUT_ROUTE,
];
